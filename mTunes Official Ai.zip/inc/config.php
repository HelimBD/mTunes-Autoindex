<?php

// Database details
$config['database']['type'] = "mysqli";
$config['database']['database'] = "auto";
$config['database']['table_prefix'] = "mtunes";

$config['database']['hostname'] = "localhost";
$config['database']['username'] = "auto";
$config['database']['password'] = "Helim@0011";

/**
 * Admin CP directory
 *  For security reasons, it is recommended you
 *  rename your Admin CP directory. You then need
 *  to adjust the value below to point to the
 *  new directory.
 */

$config['admin_dir'] ="mtunes";

/**
 * Database Encoding
 *  If you wish to set an encoding for SS uncomment
 *  the line below (if it isnt already) and change
 *  the current value to the mysql charset:
 *  http://dev.mysql.com/doc/refman/5.1/en/charset-mysql.html
 */

$config['database']['encoding'] = "utf8";