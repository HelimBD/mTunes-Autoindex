<?php

echo '<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>mTunes Auto index</title>
<meta content="width=device-width; initial-scale=1.0; maximum-scale=1.0; user-scalable=0;" name="viewport" />
<meta name="viewport" content="width=device-width" />
<link href="../assets/css/mtunes.css" type="text/css" rel="stylesheet"/>
<link rel="shortcut icon" href="/assets/images/favicon.png" />
</head>
<body>
<h2>mTunes  Autoindex</div>
<div class="bkmk"><a href="https://facebook.com/live.helim">Made  By Helim Hasan Akash</a></div>';
