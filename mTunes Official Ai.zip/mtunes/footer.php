<?php

include_once('./assets/ads/footer.php');

echo '<div class="mtunesfooter" align="center"><a href="https://mtunes.us/contactus.php">Contact Us</a> | <a href="https://mtunes.us/t/1/mtunes-terms--and--rules-must-obey.html">Terms & Service</a> | <a href="https://mtunes.us/t/40/about-mtunes.html">About Us</a> | <a href="https://mtunes.us/t/39/our-privacy-policy-must-read.html">Privacy Policy</a> | <a href="#top">Top</a><br/>&#169; <a href="https://mtunes.us">mTunes.Us</a>
</body>
</html>';