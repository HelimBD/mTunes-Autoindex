<?php

// Services
echo '<div class="mtunesmenu">Services</div>
<div class="catRow"><a href="/top/0.html">Top 20 Files</a></div>
<div class="catRow"><a href="/newitems/1.html">Last Added All Files</a></div>
<div class="catRow"><a href="/assets/disclaimer.php">Disclaimer</a></div>
</div>';

// Sponser Sites
echo '<div class="mtunesmenu">Sponsor Sites</div>
<div class="catRow"><a href="https://mtunes.us"><b>mTunes.Us-Free Wapmaster Land</b></a></div>';